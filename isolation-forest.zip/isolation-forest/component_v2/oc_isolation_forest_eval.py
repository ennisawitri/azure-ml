import os
import argparse
import numpy as np
import pandas as pd
import json
import matplotlib.pyplot as plt
import mlflow
from sklearn.metrics import roc_auc_score

def main():
    # Argument parser
    parser = argparse.ArgumentParser(description="Evaluate Isolation Forest Model")
    parser.add_argument("--model", type=str, required=True, help="Path to the trained Isolation Forest model")
    parser.add_argument("--test_data", type=str, required=True, help="Path to the testing data folder")
    parser.add_argument("--target_column", type=int, default=0, help="Index of the feature column for evaluation")
    parser.add_argument("--output_dir", type=str, required=True, help="Path to save evaluation outputs")
    args = parser.parse_args()

    # Start MLflow logging
    mlflow.start_run()

    # Load the trained model
    from joblib import load
    model_path = os.path.join(args.model, "isolation_forest_model.pkl")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found at {model_path}")
    oc_svm = load(model_path)

    # Load testing data
    X_test_path = os.path.join(args.test_data, "X_test.npy")
    timestamps_path = os.path.join(args.test_data, "timestamps_test.npy")
    sensor_values_path = os.path.join(args.test_data, "sensor_values_test.npy")

    if not os.path.exists(X_test_path) or not os.path.exists(timestamps_path) or not os.path.exists(sensor_values_path):
        raise FileNotFoundError("One or more required test data files are missing")

    X_test = np.load(X_test_path)
    timestamps = np.load(timestamps_path)
    sensor_values = np.load(sensor_values_path)

    # Validate lengths
    if not (len(timestamps) == len(sensor_values) == len(X_test)):
        raise ValueError("Lengths of timestamps_test, sensor_values, and X_test do not match!")

    # Get decision scores
    decision_scores = oc_svm.decision_function(X_test[:, args.target_column].reshape(-1, 1))

    # Calculate Proportion of Anomalies Detected (PAD)
    y_pred = (decision_scores < 0).astype(int)  # Threshold at 0
    pad = y_pred.sum() / len(y_pred)

    # Log metrics to MLflow
    metrics = {
        "Proportion of Anomalies Detected (PAD)": pad,
        "Decision Scores (Min)": decision_scores.min(),
        "Decision Scores (Max)": decision_scores.max(),
        "Decision Scores (Mean)": decision_scores.mean(),
        "Decision Scores (StdDev)": decision_scores.std(),
    }
    for key, value in metrics.items():
        mlflow.log_metric(key, value)
    print("Metrics logged to MLflow.")

    # Save metrics to file
    os.makedirs(args.output_dir, exist_ok=True)
    metrics_path = os.path.join(args.output_dir, "metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=4)
    print(f"Metrics saved to: {metrics_path}")

    # Visualize decision scores
    plt.figure(figsize=(10, 6))
    plt.hist(decision_scores, bins=50, color='blue', alpha=0.7)
    plt.title("Distribution of Decision Scores")
    plt.xlabel("Decision Score")
    plt.ylabel("Frequency")
    plt.grid()

    # Save plot to output directory
    plot_path = os.path.join(args.output_dir, "decision_scores_plot.png")
    plt.savefig(plot_path)
    print(f"Visualization saved to: {plot_path}")

    # Log plot to MLflow
    mlflow.log_artifact(plot_path, artifact_path="plots")

    # End MLflow logging
    mlflow.end_run()

if __name__ == "__main__":
    main()
