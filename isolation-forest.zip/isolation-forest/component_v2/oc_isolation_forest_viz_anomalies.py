import pandas as pd
import matplotlib.pyplot as plt
import argparse
import os

def main():
    # Argument Parser
    parser = argparse.ArgumentParser(description="Visualisasi hasil anomalies trai test dengan line time series")
    parser.add_argument("--input_folder", type=str, required = True, help="Path folder untuk input file csv anomalies")
    parser.add_argument("--output_folder", type=str, required = True, help="Path folder untuk menyimpan hasil visualisasi time series")
    args = parser.parse_args()
    
    # Mencari CSV file input di dalam folder
    csv_files = [f for f in os.listdir(args.input_folder) if f.endswith(".csv")]
    if not csv_files:
        raise FileNotFoundError(f"CSV file tidak ditemukan dalam folder: {args.input_folder}")
        
    csv_path = os.path.join(args.input_folder, csv_files[0]) # Mengambil file csv pertama jika ada beberapa file csv dalam folder
    print(f"Berhasil membaca file: {csv_path}")
    
    # Membaca csv
    df = pd.read_csv(csv_path)
    
    # Memastikan kolom yang dibutuhkan
    required_column = ["timestamp", "sensor_value", "is_anomaly", "source"]
    for col in required_column:
        if col not in df.columns:
            raise ValueError(f"Kolom tidak tersedia di dalam dataframe: {col}")
    
    # Melakukan konversi kolom timestamp menjadi datetime
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    
    # Mengambil data hanya dengan anomaly
    df_anomaly = df[df["is_anomaly"] == 1]
    
    # Memisahkan data train dan data test
    df_train = df[df["source"] == "train"]
    df_test = df[df["source"] == "test"]
    
    # Visuliasai plot time series data]
    plt.figure(figsize=(10,6))
    
    # Plot data train dengan warna biru
    plt.plot(df_train["timestamp"], df_train["sensor_value"], label="Train Data", color="blue", alpha=0.7, linewidth=1.5)

    # Plot data test dengan warna hijau
    plt.plot(df_test["timestamp"], df_test["sensor_value"], label="Test Data", color="green", alpha=0.7, linewidth=1.5)

    # Plot titik untuk is_anomaly == 1 dengan warna merah
    plt.scatter(df_anomaly["timestamp"], df_anomaly["sensor_value"], color="red", label="Anomaly", s=50, edgecolors="black", zorder=5)

    plt.title('Sensor Value Time Series with Anomalies', fontsize=14)
    plt.xlabel('Timestamp', fontsize=12)
    plt.ylabel('Sensor Value', fontsize=12)
    plt.legend()
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Simpan Hasil Visualisasi
    os.makedirs(args.output_folder, exist_ok=True)
    output_path = os.path.join(args.output_folder, "time_series_plot.png")
    plt.savefig(output_path)
    print(f"Visualization saved to: {output_path}")
          
if __name__ == "__main__":
    main()

        
    
                            