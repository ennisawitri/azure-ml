import os
import argparse
import numpy as np
import joblib
from sklearn.ensemble import IsolationForest

def main():
    # Argument parser
    parser = argparse.ArgumentParser(description="Train Isolation Forest Model")
    parser.add_argument("--train_data", type=str, required=True, help="Path to the training data folder")
    parser.add_argument("--test_data", type=str, required=True, help="Path to the testing data folder")
    parser.add_argument("--output_model", type=str, required=True, help="Path to save the trained model")
    parser.add_argument("--output_results", type=str, required=True, help="Path to save the prediction results")
    parser.add_argument("--train_anomalies", type=str, required=True, help="Path to save detected anomalies in training data")
    parser.add_argument("--contamination", type=float, default=0.1, help="Expected proportion of anomalies")
    parser.add_argument("--n_estimators", type=int, default=100, help="Number of trees in the Isolation Forest")
    args = parser.parse_args()

    # Load training and testing data (already prepared and normalized)
    X_train = np.load(os.path.join(args.train_data, "X_train.npy"))
    X_test = np.load(os.path.join(args.test_data, "X_test.npy"))
    
    # Load scaler (to inverse transform if needed)
    scaler = joblib.load(os.path.join(args.train_data, "scaler.pkl"))

    # Train Isolation Forest
    model = IsolationForest(n_estimators=args.n_estimators, contamination=args.contamination, random_state=42)
    model.fit(X_train)

    # Save trained model
    os.makedirs(args.output_model, exist_ok=True)
    joblib.dump(model, os.path.join(args.output_model, "isolation_forest_model.pkl"))

    # Predict on test data (anomaly detection)
    test_predictions = model.predict(X_test)  # Prediksi: 1 untuk normal, -1 untuk anomali
    test_predictions = np.where(test_predictions == -1, 1, 0)  # Mengubah -1 jadi 1 (anomali), 1 jadi 0 (normal)
    test_scores = model.decision_function(X_test)  # Skor anomali: lebih rendah lebih anomali

    # Save test predictions and scores
    os.makedirs(args.output_results, exist_ok=True)
    np.save(os.path.join(args.output_results, "test_predictions.npy"), test_predictions)
    np.save(os.path.join(args.output_results, "test_scores.npy"), test_scores)
    np.save(os.path.join(args.output_results, "timestamps_test.npy"), np.load(os.path.join(args.test_data, "timestamps_test.npy")))
    np.save(os.path.join(args.output_results, "sensor_values_test.npy"), np.load(os.path.join(args.test_data, "sensor_values_test.npy")))

    # Predict on training data (to detect anomalies in training data)
    train_predictions = model.predict(X_train)
    train_predictions = np.where(train_predictions == -1, 1, 0)  # Mengubah -1 jadi 1 (anomali), 1 jadi 0 (normal)
    train_scores = model.decision_function(X_train)

    # Save training anomalies and results
    np.save(os.path.join(args.train_anomalies, "train_predictions.npy"), train_predictions)
    np.save(os.path.join(args.train_anomalies, "train_scores.npy"), train_scores)
    np.save(os.path.join(args.train_anomalies, "timestamps_train.npy"), np.load(os.path.join(args.train_data, "timestamps_train.npy")))
    np.save(os.path.join(args.train_anomalies, "sensor_values_train.npy"), np.load(os.path.join(args.train_data, "sensor_values_train.npy")))

    print("Model training and prediction completed.")

if __name__ == "__main__":
    main()
