import os
import argparse
import pandas as pd

def main():
    # Argument Parser
    parser = argparse.ArgumentParser(description="Merge train n test data anomalies with source column")
    parser.add_argument("--output_result", type=str, required=True, help="Path to the input folder containing CSV files")
    parser.add_argument("--output_folder", type=str, required=True, help="Path to save the merged output CSV folder")
    args = parser.parse_args()
    
    # Memastikan folder input ada
    if not os.path.exists(args.output_result):
        raise FileNotFoundError(f"Input folder not found: {args.output_result}")
        
    # Mengecek keberadaan train dan test anomalies di dalam folder
    train_file = os.path.join(args.output_result, "train_anomalies.csv")
    test_file = os.path.join(args.output_result, "test_predictions.csv")

    if not os.path.exists(train_file) or not os.path.exists(test_file):
        raise FileNotFoundError("Both train_anomalies.csv and prediction.csv must be present in the input folder.")
        
    # Read kedua dataset
    train_df = pd.read_csv(train_file)
    test_df = pd.read_csv(test_file)
    
    # Menambahkan kolom "source" untuk sumber data
    train_df['source'] = "train"
    test_df['source'] = "test"
    
    # Gabungkan kedua dataset
    merge_df = pd.concat([train_df, test_df], ignore_index = True)
    
    # Membuat output foder 
    os.makedirs(args.output_folder, exist_ok = True)
    
    # Menyimpan hasilnya didalam folder format .csv
    output_file_path = os.path.join(args.output_folder, "merged_result.csv")
    merge_df.to_csv(output_file_path, index = False)
    
    print(f"Data berhasil disimpan di: {output_file_path}")

if __name__ == "__main__":
    main()