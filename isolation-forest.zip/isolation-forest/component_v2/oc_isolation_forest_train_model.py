import os
import argparse
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import IsolationForest
from sklearn.model_selection import ParameterGrid

def train_isolation_forest(X_train, param_grid):
    """Melakukan Hyperparameter Tuning menggunakan Grid Search."""
    best_model = None
    best_score = -np.inf  # Semakin rendah anomaly score, semakin baik
    best_params = None

    print("Starting Hyperparameter Tuning...")
    for params in ParameterGrid(param_grid):
        print(f"Testing parameters: {params}")

        model = IsolationForest(
            n_estimators=params["n_estimators"],
            contamination=params["contamination"],
            max_features=params["max_features"],
            random_state=42
        )
        model.fit(X_train)

        # Skor anomaly rata-rata (Semakin negatif, semakin baik)
        anomaly_scores = model.decision_function(X_train).mean()
        print(f"Mean Decision Score: {anomaly_scores}")

        if anomaly_scores > best_score:
            best_score = anomaly_scores
            best_model = model
            best_params = params

    print(f"Best Parameters: {best_params}, Best Score: {best_score}")
    return best_model, best_params

def main():
    # Argument parser
    parser = argparse.ArgumentParser(description="Train Isolation Forest Model with Hyperparameter Tuning")
    parser.add_argument("--train_data", type=str, required=True, help="Path to the training data folder")
    parser.add_argument("--test_data", type=str, required=True, help="Path to the testing data folder")
    parser.add_argument("--train_anomalies", type=str, required=True, help="Path to save detected training anomalies")
    parser.add_argument("--output_model", type=str, required=True, help="Path to save the trained model")
    parser.add_argument("--output_results", type=str, required=True, help="Path to save prediction results")
    args = parser.parse_args()

    # Load training data
    train_file_path = os.path.join(args.train_data, "X_train.npy")
    X_train = np.load(train_file_path)

    # Load timestamps dan sensor values training data
    train_timestamps_path = os.path.join(args.train_data, "timestamps_train.npy")
    train_timestamps = np.load(train_timestamps_path)

    train_sensor_values_path = os.path.join(args.train_data, "sensor_values_train.npy")
    train_sensor_values = np.load(train_sensor_values_path)

    # Load testing data
    test_file_path = os.path.join(args.test_data, "X_test.npy")
    X_test = np.load(test_file_path)

    # Load timestamps dan sensor values testing data
    test_timestamps_path = os.path.join(args.test_data, "timestamps_test.npy")
    test_timestamps = np.load(test_timestamps_path)

    test_sensor_values_path = os.path.join(args.test_data, "sensor_values_test.npy")
    test_sensor_values = np.load(test_sensor_values_path)

    print(f"Training data shape: {X_train.shape}")
    print(f"Test data shape: {X_test.shape}")

    # **Hyperparameter Grid Search**
    param_grid = {
        "n_estimators": [50, 100, 150],
        "contamination": [0.05, 0.1, 0.15],
        "max_features": [0.5, 0.75, 1.0]
    }

    # **Train the Best Model**
    best_model, best_params = train_isolation_forest(X_train, param_grid)

    # Save the best trained model
    os.makedirs(args.output_model, exist_ok=True)
    model_path = os.path.join(args.output_model, "isolation_forest_model.pkl")
    joblib.dump(best_model, model_path)
    print(f"Best Model saved to: {model_path}")

    # **Predict anomalies in training data**
    print("Detecting anomalies in training data...")
    y_train_pred = best_model.predict(X_train)
    y_train_pred = np.where(y_train_pred == -1, 1, 0)  # Convert -1 (anomaly) to 1

    # Save training anomaly results
    train_anomalies_df = pd.DataFrame({
        "timestamp": pd.to_datetime(train_timestamps),
        "sensor_value": train_sensor_values[:, 0],  # Menggunakan fitur pertama
        "is_anomaly": y_train_pred
    })
    os.makedirs(args.train_anomalies, exist_ok=True)
    train_anomalies_csv_path = os.path.join(args.output_results, "train_anomalies.csv")
    train_anomalies_df.to_csv(train_anomalies_csv_path, index=False)
    print(f"Training anomalies saved to: {train_anomalies_csv_path}")

    # **Predict anomalies in test data**
    print("Making predictions on test data...")
    y_test_pred = best_model.predict(X_test)
    y_test_pred = np.where(y_test_pred == -1, 1, 0)  # Convert -1 (anomaly) to 1

    # Save test predictions
    results_df = pd.DataFrame({
        "timestamp": pd.to_datetime(test_timestamps),
        "sensor_value": test_sensor_values[:, 0],  # Menggunakan fitur pertama
        "is_anomaly": y_test_pred
    })
    results_csv_path = os.path.join(args.output_results, "test_predictions.csv")
    results_df.to_csv(results_csv_path, index=False)
    print(f"Test predictions saved to: {results_csv_path}")

if __name__ == "__main__":
    main()
