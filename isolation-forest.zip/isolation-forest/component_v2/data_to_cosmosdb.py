import argparse
import os
import sys
import pandas as pd
from azure.cosmos import CosmosClient, PartitionKey
import hashlib
import traceback  # Untuk menampilkan error lengkap

def main():
    try:
        # DEBUG: Tampilkan semua argumen yang diterima oleh script
        print("===== DEBUG: Command Line Arguments =====")
        print(" ".join(sys.argv))
        print("=========================================")

        # Argument parser
        parser = argparse.ArgumentParser(description="Convert CSV to CosmosDB")
        parser.add_argument("--output_dir", type=str, required=True, help="Path to the CSV folder")
        parser.add_argument("--cosmos_conn_str", type=str, required=True, help="CosmosDB connection string")
        parser.add_argument("--database_name", type=str, required=True, help="Database name")
        parser.add_argument("--container_name", type=str, required=True, help="Container name")
        parser.add_argument("--partition_key", type=str, default="/id", help="Partition key")

        args = parser.parse_args()

        # DEBUG: Cek apakah args memiliki nilai yang benar
        print("===== DEBUG: ARGUMENTS RECEIVED =====")
        print(f"Output Dir       : {args.output_dir}")
        print(f"Cosmos Conn Str  : {args.cosmos_conn_str}")
        print(f"Database Name    : {args.database_name}")
        print(f"Container Name   : {args.container_name}")
        print(f"Partition Key    : {args.partition_key}")
        print("=====================================")

        # Periksa apakah direktori output benar-benar ada
        if not os.path.exists(args.output_dir):
            raise FileNotFoundError(f"Output directory not found: {args.output_dir}")

        # DEBUG: Tampilkan isi direktori output
        print("===== DEBUG: FILES IN OUTPUT DIRECTORY =====")
        print(os.listdir(args.output_dir))
        print("============================================")

        # Cari file CSV di dalam direktori
        csv_files = [f for f in os.listdir(args.output_dir) if f.endswith(".csv")]
        if not csv_files:
            raise FileNotFoundError(f"No CSV files found in directory: {args.output_dir}")

        input_csv_path = os.path.join(args.output_dir, csv_files[0])
        print(f"Found CSV file: {input_csv_path}")

        # Load CSV
        df = pd.read_csv(input_csv_path)
        print(f"Loaded {len(df)} records from CSV.")

        # Pastikan kolom sesuai
        df.columns = ["timestamp", "sensor_value", "is_anomaly", "source"]

        # Convert timestamp ke datetime jika belum dalam format datetime
        df["timestamp"] = pd.to_datetime(df["timestamp"])

        # Menambahkan kolom sensor_code dan notes
        df["sensor_code"] = "1001001001"  # Semua baris akan memiliki sensor_code yang sama
        df["notes"] = ""  # Kolom notes dibiarkan kosong

        # Koneksi ke Cosmos DB
        print("Connecting to Cosmos DB...")
        client = CosmosClient.from_connection_string(args.cosmos_conn_str)
        database = client.create_database_if_not_exists(id=args.database_name)
        container = database.create_container_if_not_exists(
            id=args.container_name,
            partition_key=PartitionKey(path=args.partition_key),
            offer_throughput=400
        )
        print(f"Connected to Cosmos DB database '{args.database_name}', container '{args.container_name}'.")

        # Masukkan data ke Cosmos DB
        for _, row in df.iterrows():
            # Membuat ID dengan hashing gabungan dari timestamp dan sensor_code
            id_input = f"{row['sensor_code']}_{row['timestamp']}"
            hashed_id = hashlib.sha256(id_input.encode('utf-8')).hexdigest()  # Menggunakan SHA-256 untuk menghasilkan ID unik

            document = {
                "id": hashed_id,  # ID yang sudah di-hash
                "timestamp": row["timestamp"].strftime("%Y-%m-%d %H:%M:%S"),  # Format timestamp ke string
                "sensor_value": row["sensor_value"],
                "sensor_code": row["sensor_code"],
                "flag": row["is_anomaly"], 
                "notes": row["notes"],
                "source": row["source"]  # Menambahkan source ke dokumen
            }
            # Menggunakan upsert_item untuk memasukkan atau memperbarui item
            container.upsert_item(document)

        print("Data insertion completed.")

    except Exception as e:
        print("\n===== ERROR OCCURRED =====")
        print(f"Error: {str(e)}")
        print("Stack Trace:")
        traceback.print_exc()  # Print error lengkap
        print("==========================\n")
        sys.exit(1)  # Exit dengan status error

if __name__ == "__main__":
    main()
