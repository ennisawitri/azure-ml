import os
import argparse
import numpy as np
import pandas as pd
from sklearn.svm import OneClassSVM
from sklearn.metrics import roc_auc_score
import joblib

def evaluate_model(oc_svm, X_test, y_pred, decision_scores, timestamps, sensor_values, target_column, output_dir):
    """
    Evaluate the model and save metrics and predictions.
    """
    # Calculate Proportion of Anomalies Detected (PAD)
    pad = y_pred.sum() / len(y_pred)

    # Save predictions
    predictions_df = pd.DataFrame({
        "timestamp": pd.to_datetime(timestamps),
        "sensor_value": sensor_values[:, target_column],  # Use raw sensor values for visualization
        "is_anomaly": y_pred
    })
    predictions_csv_path = os.path.join(output_dir, "predictions.csv")
    predictions_df.to_csv(predictions_csv_path, index=False)
    print(f"Predictions saved to: {predictions_csv_path}")

    # Return evaluation metric (e.g., PAD for simplicity)
    return pad

def main():
    # Argument parser
    parser = argparse.ArgumentParser(description="Train One-Class SVM Model with Hyperparameter Tuning")
    parser.add_argument("--train_data", type=str, required=True, help="Path to the training data folder")
    parser.add_argument("--test_data", type=str, required=True, help="Path to the testing data folder")
    parser.add_argument("--target_column", type=int, default=0, help="Index of the feature column for training")
    parser.add_argument("--model", type=str, required=True, help="Path to save the best model")
    parser.add_argument("--output_dir", type=str, required=True, help="Path to save evaluation results")
    args = parser.parse_args()

    # Load training data
    train_data_path = os.path.join(args.train_data, "X_train.npy")
    X_train = np.load(train_data_path)

    # Load testing data
    test_data_path = os.path.join(args.test_data, "X_test.npy")
    X_test = np.load(test_data_path)

    # Load sensor values from test data
    sensor_values_path = os.path.join(args.test_data, "sensor_values_test.npy")
    sensor_values = np.load(sensor_values_path)

    # Load timestamps from test data
    timestamps_path = os.path.join(args.test_data, "timestamps.npy")
    timestamps = np.load(timestamps_path)

    # Validate lengths
    if not (len(sensor_values) == len(timestamps) == len(X_test)):
        raise ValueError("Lengths of sensor_values, timestamps, and X_test do not match!")

    # Select the target column
    print(f"Using target column: {args.target_column}")
    X_train_target = X_train[:, args.target_column]
    X_test_target = X_test[:, args.target_column]

    # Hyperparameter grid
    param_grid = {
        "nu": [0.01, 0.05, 0.1],
        "gamma": ["auto", 0.1, 0.5, 1],
        "kernel": ["rbf"]
    }

    best_score = -float("inf")
    best_params = None
    best_model = None

    # Grid Search for Hyperparameter Tuning
    print("Starting hyperparameter tuning...")
    for nu in param_grid["nu"]:
        for gamma in param_grid["gamma"]:
            for kernel in param_grid["kernel"]:
                print(f"Testing model with nu={nu}, gamma={gamma}, kernel={kernel}...")

                # Train model
                oc_svm = OneClassSVM(nu=nu, gamma=gamma, kernel=kernel)
                oc_svm.fit(X_train_target.reshape(-1, 1))

                # Evaluate model
                decision_scores = oc_svm.decision_function(X_test_target.reshape(-1, 1))
                y_pred = (decision_scores < 0).astype(int)  # -1 (anomaly) -> 1 (anomaly)
                pad = evaluate_model(oc_svm, X_test_target, y_pred, decision_scores, timestamps, sensor_values, args.target_column, args.output_dir)

                print(f"PAD for nu={nu}, gamma={gamma}, kernel={kernel}: {pad:.4f}")

                # Save the best model based on PAD
                if pad > best_score:
                    best_score = pad
                    best_params = {"nu": nu, "gamma": gamma, "kernel": kernel}
                    best_model = oc_svm

    # Save the best model
    os.makedirs(args.model, exist_ok=True)
    model_path = os.path.join(args.model, "oc_svm_best_model.pkl")
    joblib.dump(best_model, model_path)
    print(f"Best model saved to: {model_path}")
    print(f"Best hyperparameters: {best_params}")
    print(f"Best PAD: {best_score:.4f}")

if __name__ == "__main__":
    main()
