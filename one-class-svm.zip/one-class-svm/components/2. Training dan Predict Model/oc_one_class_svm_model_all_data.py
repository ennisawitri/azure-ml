import os
import argparse
import numpy as np
import pandas as pd
from sklearn.svm import OneClassSVM
import joblib


def evaluate_model(model, X_data, timestamps, sensor_values, target_column, source):
    decision_scores = model.decision_function(X_data.reshape(-1, 1))
    y_pred = (decision_scores < 0).astype(int)

    predictions_df = pd.DataFrame({
        "timestamp": pd.to_datetime(timestamps),
        "sensor_value": sensor_values[:, target_column],
        "is_anomaly": y_pred,
        "source": source
    })

    return predictions_df


def main():
    # Argument parser
    parser = argparse.ArgumentParser(description="Train One-Class SVM Model for Anomaly Detection with Hyperparameter Tuning")
    parser.add_argument("--train_data", type=str, required=True, help="Path to the training data folder")
    parser.add_argument("--test_data", type=str, required=True, help="Path to the testing data folder")
    parser.add_argument("--target_column", type=int, default=0, help="Index of the feature column for training")
    parser.add_argument("--output_model", type=str, required=True, help="Path to save the trained model")
    parser.add_argument("--output_results", type=str, required=True, help="Path to save prediction results")
    args = parser.parse_args()

    # Load training data
    X_train = np.load(os.path.join(args.train_data, "X_train.npy"))
    train_timestamps = np.load(os.path.join(args.train_data, "timestamps_train.npy"))
    train_sensor_values = np.load(os.path.join(args.train_data, "sensor_values_train.npy"))

    # Load test data
    X_test = np.load(os.path.join(args.test_data, "X_test.npy"))
    test_timestamps = np.load(os.path.join(args.test_data, "timestamps_test.npy"))
    test_sensor_values = np.load(os.path.join(args.test_data, "sensor_values_test.npy"))

    print(f"Training data shape: {X_train.shape}")
    print(f"Test data shape: {X_test.shape}")

    # Select the target column
    X_train_target = X_train[:, args.target_column]
    X_test_target = X_test[:, args.target_column]

    # Hyperparameter grid
    param_grid = {
        "nu": [0.01, 0.05, 0.1],
        "gamma": ["auto", 0.1, 0.5, 1],
        "kernel": ["rbf"]
    }

    best_score = -float("inf")
    best_params = None
    best_model = None

    # Grid Search for Hyperparameter Tuning
    print("Starting hyperparameter tuning...")
    for nu in param_grid["nu"]:
        for gamma in param_grid["gamma"]:
            for kernel in param_grid["kernel"]:
                print(f"Testing model with nu={nu}, gamma={gamma}, kernel={kernel}...")

                # Train model
                model = OneClassSVM(nu=nu, gamma=gamma, kernel=kernel)
                model.fit(X_train_target.reshape(-1, 1))

                # Evaluate model on test data
                test_predictions_df = evaluate_model(
                    model, X_test_target, test_timestamps, test_sensor_values,
                    args.target_column, "test"
                )

                pad = test_predictions_df['is_anomaly'].sum() / len(test_predictions_df)
                print(f"PAD for nu={nu}, gamma={gamma}, kernel={kernel}: {pad:.4f}")

                # Save best model based on PAD
                if pad > best_score:
                    best_score = pad
                    best_params = {"nu": nu, "gamma": gamma, "kernel": kernel}
                    best_model = model

                    # Save test predictions
                    os.makedirs(args.output_results, exist_ok=True)
                    results_csv_path = os.path.join(args.output_results, "test_predictions.csv")
                    test_predictions_df.to_csv(results_csv_path, index=False)
                    print(f"Test predictions saved to: {results_csv_path}")

                    # Save training anomalies
                    train_predictions_df = evaluate_model(
                        best_model, X_train_target, train_timestamps, train_sensor_values,
                        args.target_column, "train"
                    )
                    train_anomalies_csv_path = os.path.join(args.output_results, "train_anomalies.csv")
                    train_predictions_df.to_csv(train_anomalies_csv_path, index=False)
                    print(f"Training anomalies saved to: {train_anomalies_csv_path}")

    # Save the best model
    os.makedirs(args.output_model, exist_ok=True)
    model_path = os.path.join(args.output_model, "one_class_svm_model.pkl")
    joblib.dump(best_model, model_path)
    print(f"Best model saved to: {model_path}")
    print(f"Best hyperparameters: {best_params}")
    print(f"Best PAD: {best_score:.4f}")


if __name__ == "__main__":
    main()

   

