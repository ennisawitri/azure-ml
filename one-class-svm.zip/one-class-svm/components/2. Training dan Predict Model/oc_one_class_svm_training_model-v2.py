import os
import argparse
import numpy as np
import joblib
from sklearn.svm import OneClassSVM

def main():
    # Argument parser
    parser = argparse.ArgumentParser(description="Train One-Class SVM Model using all data for training.")
    parser.add_argument("--train_data", type=str, required=True, help="Path to the training data folder")
    parser.add_argument("--target_column", type=int, default=0, help="Index of the feature column for training")
    parser.add_argument("--model", type=str, required=True, help="Path to save the trained model")
    args = parser.parse_args()

    # Load training data
    train_data_path = os.path.join(args.train_data, "X_train.npy")
    if not os.path.exists(train_data_path):
        raise FileNotFoundError(f"Training data not found at {train_data_path}")
    X_train = np.load(train_data_path)

    # Select the target column
    print(f"Using target column: {args.target_column}")
    X_train_target = X_train[:, args.target_column]

    # Hyperparameter grid
    param_grid = {
        "nu": [0.01, 0.05, 0.1],
        "gamma": ["auto", 0.1, 0.5, 1],
        "kernel": ["rbf"]
    }

    best_score = -float("inf")
    best_params = None
    best_model = None

    # Grid Search for Hyperparameter Tuning
    print("Starting hyperparameter tuning...")
    for nu in param_grid["nu"]:
        for gamma in param_grid["gamma"]:
            for kernel in param_grid["kernel"]:
                print(f"Testing model with nu={nu}, gamma={gamma}, kernel={kernel}...")

                # Train model
                oc_svm = OneClassSVM(nu=nu, gamma=gamma, kernel=kernel)
                oc_svm.fit(X_train_target.reshape(-1, 1))

                # Calculate decision scores (for future evaluation, if needed)
                decision_scores = oc_svm.decision_function(X_train_target.reshape(-1, 1))

                # Use mean of decision scores as a proxy for model quality
                model_score = decision_scores.mean()
                print(f"Model score (mean decision score) for nu={nu}, gamma={gamma}, kernel={kernel}: {model_score:.4f}")

                # Save the best model based on decision score
                if model_score > best_score:
                    best_score = model_score
                    best_params = {"nu": nu, "gamma": gamma, "kernel": kernel}
                    best_model = oc_svm

    # Save the best model
    os.makedirs(args.model, exist_ok=True)
    model_path = os.path.join(args.model, "oc_svm_best_model.pkl")
    joblib.dump(best_model, model_path)
    print(f"Best model saved to: {model_path}")
    print(f"Best hyperparameters: {best_params}")
    print(f"Best score (mean decision score): {best_score:.4f}")

if __name__ == "__main__":
    main()
