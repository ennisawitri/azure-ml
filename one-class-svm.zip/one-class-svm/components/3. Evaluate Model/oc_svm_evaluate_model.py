import os
import argparse
import numpy as np
import pandas as pd
import json
import matplotlib.pyplot as plt
import mlflow
from joblib import load
from sklearn.svm import OneClassSVM


def evaluate_model(model, X_data, timestamps, sensor_values, target_column, source):
    decision_scores = model.decision_function(X_data.reshape(-1, 1))
    y_pred = (decision_scores < 0).astype(int)

    predictions_df = pd.DataFrame({
        "timestamp": pd.to_datetime(timestamps),
        "sensor_value": sensor_values[:, target_column],
        "is_anomaly": y_pred,
        "source": source
    })

    return predictions_df


def main():
    # Argument parser
    parser = argparse.ArgumentParser(description="Evaluate One-Class SVM Model")
    parser.add_argument("--model", type=str, required=True, help="Path to the trained One-Class SVM model folder")
    parser.add_argument("--model_filename", type=str, default="one_class_svm_model.pkl", help="Filename of the trained model")
    parser.add_argument("--test_data", type=str, required=True, help="Path to the testing data folder")
    parser.add_argument("--target_column", type=int, default=0, help="Index of the feature column for evaluation")
    parser.add_argument("--output_results", type=str, required=True, help="Path to save prediction results and evaluation metrics")
    args = parser.parse_args()

    # Start MLflow logging
    mlflow.start_run()

    # Load the trained model
    model_path = os.path.join(args.model, args.model_filename)
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found at {model_path}")
    oc_svm = load(model_path)
    print(f"Loaded model from: {model_path}")

    # Load test data
    X_test = np.load(os.path.join(args.test_data, "X_test.npy"))
    timestamps = np.load(os.path.join(args.test_data, "timestamps_test.npy"))
    sensor_values = np.load(os.path.join(args.test_data, "sensor_values_test.npy"))

    # Validate lengths
    if not (len(timestamps) == len(sensor_values) == len(X_test)):
        raise ValueError("Lengths of timestamps, sensor_values, and X_test do not match!")

    print(f"Test data shape: {X_test.shape}")

    # Select the target column
    X_test_target = X_test[:, args.target_column]

    # Get decision scores
    decision_scores = oc_svm.decision_function(X_test_target.reshape(-1, 1))

    # Calculate Proportion of Anomalies Detected (PAD)
    y_pred = (decision_scores < 0).astype(int)  # Threshold at 0
    pad = y_pred.sum() / len(y_pred)

    # Log metrics to MLflow
    metrics = {
        "Proportion of Anomalies Detected (PAD)": pad,
        "Decision Scores (Min)": decision_scores.min(),
        "Decision Scores (Max)": decision_scores.max(),
        "Decision Scores (Mean)": decision_scores.mean(),
        "Decision Scores (StdDev)": decision_scores.std(),
    }
    for key, value in metrics.items():
        mlflow.log_metric(key, value)
    print("Metrics logged to MLflow.")

    # Save metrics to file
    os.makedirs(args.output_results, exist_ok=True)
    metrics_path = os.path.join(args.output_results, "metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=4)
    print(f"Metrics saved to: {metrics_path}")

    # Visualize decision scores
    plt.figure(figsize=(10, 6))
    plt.hist(decision_scores, bins=50, color='blue', alpha=0.7)
    plt.title("Distribution of Decision Scores")
    plt.xlabel("Decision Score")
    plt.ylabel("Frequency")
    plt.grid()

    # Save plot to output directory
    plot_path = os.path.join(args.output_results, "decision_scores_plot.png")
    plt.savefig(plot_path)
    print(f"Visualization saved to: {plot_path}")

    # Log plot to MLflow
    mlflow.log_artifact(plot_path, artifact_path="plots")

    # Save test predictions to CSV
    test_predictions_df = evaluate_model(oc_svm, X_test_target, timestamps, sensor_values, args.target_column, "test")
    test_predictions_csv_path = os.path.join(args.output_results, "test_predictions.csv")
    test_predictions_df.to_csv(test_predictions_csv_path, index=False)
    print(f"Test predictions saved to: {test_predictions_csv_path}")

    # End MLflow logging
    mlflow.end_run()


if __name__ == "__main__":
    main()

   
