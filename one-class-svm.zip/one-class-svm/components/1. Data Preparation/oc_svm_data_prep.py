import os
import argparse
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import joblib

def main():
    # Argument parser
    parser = argparse.ArgumentParser(description="Data Preparation for One-Class SVM")
    parser.add_argument("--data", type=str, required=True, help="Path to the input CSV file or directory containing it")
    parser.add_argument("--test_train_ratio", type=float, default=0.2, help="Proportion of data used for testing")
    parser.add_argument("--feature_columns", type=str, required=True, help="Comma-separated list of feature column names")
    parser.add_argument("--timestamp_column", type=str, required=True, help="Name of the timestamp column in the dataset")
    parser.add_argument("--train_data", type=str, required=True, help="Path to save the training data folder")
    parser.add_argument("--test_data", type=str, required=True, help="Path to save the testing data folder")
    parser.add_argument("--missing_value_strategy", type=str, default="mean", choices=["mean", "median", "drop"], help="Strategy to handle missing values")
    args = parser.parse_args()

    # Handle input data path
    if os.path.isdir(args.data):
        csv_files = [f for f in os.listdir(args.data) if f.endswith(".csv")]
        if not csv_files:
            raise FileNotFoundError(f"No CSV file found in directory: {args.data}")
        csv_file_path = os.path.join(args.data, csv_files[0])
    else:
        csv_file_path = args.data

    # Load dataset
    print(f"Loading data from: {csv_file_path}")
    df = pd.read_csv(csv_file_path)
    print(f"Dataset loaded with shape: {df.shape}")

    # Validate timestamp column
    if args.timestamp_column not in df.columns:
        raise ValueError(f"Timestamp column '{args.timestamp_column}' not found in dataset")

    # Convert timestamp column to datetime
    print(f"Processing timestamp column: {args.timestamp_column}")
    timestamps = pd.to_datetime(df[args.timestamp_column]).to_numpy()

    # Select feature columns
    feature_columns = args.feature_columns.split(",")
    print(f"Using feature columns: {feature_columns}")
    X = df[feature_columns]

    # Handle missing values
    print("Checking and handling missing values...")
    if X.isnull().values.any():
        print(f"Missing values detected in feature columns: {X.isnull().sum()}")
        if args.missing_value_strategy == "mean":
            X = X.fillna(X.mean())
            print("Filled missing values with column mean.")
        elif args.missing_value_strategy == "median":
            X = X.fillna(X.median())
            print("Filled missing values with column median.")
        elif args.missing_value_strategy == "drop":
            X = X.dropna()
            timestamps = timestamps[X.index]  # Sinkronkan timestamps dengan data
            print("Dropped rows with missing values.")
    else:
        print("No missing values detected.")

    
    # Hitung indeks split berdasarkan 80% training dan 20% testing
    split_index = int(len(X) * 0.8)

    # Data training (80% pertama)
    X_train, timestamps_train = X[:split_index], timestamps[:split_index]

    # Data testing (20% terakhir)
    X_test, timestamps_test = X[split_index:], timestamps[split_index:]


    # Periksa panjang array setelah split
    print(f"Length of X_train: {len(X_train)}, timestamps_train: {len(timestamps_train)}")
    print(f"Length of X_test: {len(X_test)}, timestamps_test: {len(timestamps_test)}")

    # Normalisasi data menggunakan StandardScaler
    print("Normalizing data using StandardScaler...")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Simpan scaler ke file agar dapat digunakan kembali
    scaler_path = os.path.join(args.train_data, "scaler.pkl")
    os.makedirs(args.train_data, exist_ok=True)
    joblib.dump(scaler, scaler_path)
    print(f"Scaler saved to: {scaler_path}")

    # Simpan train data (sudah dinormalisasi)
    train_data_path = os.path.join(args.train_data, "X_train.npy")
    np.save(train_data_path, X_train_scaled)
    print(f"Training data saved to: {train_data_path}")

    # Simpan test data (sudah dinormalisasi)
    os.makedirs(args.test_data, exist_ok=True)
    test_data_path = os.path.join(args.test_data, "X_test.npy")
    np.save(test_data_path, X_test_scaled)
    print(f"Testing data saved to: {test_data_path}")

    # Simpan raw sensor values untuk test data (tidak dinormalisasi, untuk visualisasi)
    test_sensor_values_path = os.path.join(args.test_data, "sensor_values_test.npy")
    np.save(test_sensor_values_path, X_test.to_numpy())
    print(f"Test sensor values saved to: {test_sensor_values_path}")

    # Simpan timestamps untuk test data
    test_timestamps_path = os.path.join(args.test_data, "timestamps.npy")
    np.save(test_timestamps_path, timestamps_test)
    print(f"Test timestamps saved to: {test_timestamps_path}")

if __name__ == "__main__":
    main()
