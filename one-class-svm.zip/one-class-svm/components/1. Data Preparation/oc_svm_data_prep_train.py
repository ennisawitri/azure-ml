import os
import argparse
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import joblib

def main():
    parser = argparse.ArgumentParser(description="Data Preparation for One-Class SVM (Training Only)")
    parser.add_argument("--data", type=str, required=True, help="Path to the input CSV file or directory containing it")
    parser.add_argument("--feature_columns", type=str, required=True, help="Comma-separated list of feature column names")
    parser.add_argument("--train_data", type=str, required=True, help="Path to save the training data folder")
    args = parser.parse_args()


    # Handle input data path
    if os.path.isdir(args.data):
        csv_files = [f for f in os.listdir(args.data) if f.endswith(".csv")]
        if not csv_files:
            raise FileNotFoundError(f"No CSV file found in directory: {args.data}")
        csv_file_path = os.path.join(args.data, csv_files[0])
    else:
        csv_file_path = args.data

    # Load dataset
    print(f"Loading data from: {csv_file_path}")
    df = pd.read_csv(csv_file_path)
    print(f"Dataset loaded with shape: {df.shape}")
    
    # Select feature columns
    feature_columns = args.feature_columns.split(",")
    print(f"Using feature columns: {feature_columns}")
    X = df[feature_columns]

    # Normalize data
    print("Normalizing data using StandardScaler...")
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Save scaler to file
    os.makedirs(args.train_data, exist_ok=True)
    scaler_path = os.path.join(args.train_data, "scaler.pkl")
    joblib.dump(scaler, scaler_path)
    print(f"Scaler saved to: {scaler_path}")

    # Save normalized training data
    train_data_path = os.path.join(args.train_data, "X_train.npy")
    np.save(train_data_path, X_scaled)
    print(f"Training data saved to: {train_data_path}")

if __name__ == "__main__":
    main()
