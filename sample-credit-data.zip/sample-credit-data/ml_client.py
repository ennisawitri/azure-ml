from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential
from azure.ai.ml.entities import Data
from azure.ai.ml.constants import AssetTypes

# authenticate
credential = DefaultAzureCredential()

# Get a handle to the workspace
ml_client = MLClient(
    credential=credential,
    subscription_id="545de186-b8b5-4f23-aba9-b7f0a043666d",
    resource_group_name="ASDP",
    workspace_name="azure-ml-workspace",
)